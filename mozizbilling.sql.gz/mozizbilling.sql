-- Adminer 4.8.1 MySQL 10.4.24-MariaDB dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `attendancehistories`;
CREATE TABLE `attendancehistories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `attdate` date NOT NULL,
  `checkin` time NOT NULL,
  `checkout` time DEFAULT NULL,
  `breakid` int(11) DEFAULT NULL,
  `branchid` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_id` (`employee_id`),
  KEY `breakid` (`breakid`),
  KEY `branchid` (`branchid`),
  CONSTRAINT `attendancehistories_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `attendancehistories_ibfk_2` FOREIGN KEY (`breakid`) REFERENCES `companybreaks` (`id`),
  CONSTRAINT `attendancehistories_ibfk_3` FOREIGN KEY (`branchid`) REFERENCES `branches` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `attendancehistories` (`id`, `employee_id`, `attdate`, `checkin`, `checkout`, `breakid`, `branchid`, `notes`, `created_at`, `updated_at`) VALUES
(1,	119,	'2023-02-28',	'02:00:00',	'06:00:00',	2,	1,	NULL,	'2023-02-28 00:30:35',	'2023-02-28 00:30:41');

DROP TABLE IF EXISTS `attendances`;
CREATE TABLE `attendances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `attdate` date NOT NULL,
  `status` varchar(255) NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_id` (`employee_id`),
  CONSTRAINT `attendances_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `attendances` (`id`, `employee_id`, `attdate`, `status`, `notes`, `created_at`, `updated_at`) VALUES
(1,	119,	'2023-02-28',	'Present',	NULL,	'2023-02-27 19:00:35',	'2023-02-27 19:00:35');

DROP TABLE IF EXISTS `blogs`;
CREATE TABLE `blogs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `blogs_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `branches`;
CREATE TABLE `branches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `branch_name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `branches` (`id`, `company_id`, `branch_name`, `address`, `created_at`, `updated_at`) VALUES
(1,	1,	'Store 2',	'Theni Road',	'2023-02-15 16:19:22',	'2023-02-15 10:49:22'),
(2,	1,	'Store 1',	'checkanam',	'2023-02-15 16:19:06',	'2023-02-15 10:49:06'),
(3,	1,	'fgdf',	'fdg',	'2023-02-25 12:16:14',	'2023-02-25 12:16:14');

DROP TABLE IF EXISTS `brands`;
CREATE TABLE `brands` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `brands` (`id`, `company_id`, `name`, `created_at`, `updated_at`) VALUES
(1,	0,	'Aachi',	'2023-08-24 22:37:36',	NULL),
(2,	0,	'Shakti masala',	'2023-08-24 22:37:36',	NULL);

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT 0,
  `type` tinyint(4) NOT NULL COMMENT '1=> Product 2=> Services',
  `name` varchar(255) NOT NULL,
  `description` tinytext NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `company_id` (`company_id`),
  CONSTRAINT `categories_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `categories` (`id`, `company_id`, `parent_id`, `type`, `name`, `description`, `created_at`, `updated_at`) VALUES
(2,	1,	0,	1,	'Stationaries',	'Stationaries',	'2023-07-20 17:00:16',	NULL),
(3,	1,	0,	1,	'Notebooks',	'Notebooks',	'2023-07-20 17:00:16',	NULL),
(4,	1,	0,	2,	'Web development',	'Web development',	'2023-07-20 17:00:16',	NULL);

DROP TABLE IF EXISTS `companies`;
CREATE TABLE `companies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `contact_person_name` varchar(255) NOT NULL,
  `contact_person_phone` varchar(255) NOT NULL,
  `contact_person_email` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `plan` varchar(255) NOT NULL,
  `subscription_status` tinyint(4) NOT NULL,
  `subscription_due_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `companies` (`id`, `name`, `contact_person_name`, `contact_person_phone`, `contact_person_email`, `logo`, `plan`, `subscription_status`, `subscription_due_date`, `created_at`, `updated_at`) VALUES
(1,	'Kamatchi Restaurant',	'Mona',	'8072403631',	'mona.azhagesan@gmail.com',	'/storage/companies/kamatchi.png',	'Basic',	1,	'2023-02-07',	'2023-02-10 13:16:43',	NULL),
(2,	'Flex board company',	'Mona',	'8072403631',	'mona.azhagesan@gmail.com',	'/storage/companies/kamatchi.png',	'Basic',	1,	'2023-02-07',	'2023-02-10 13:16:43',	NULL),
(3,	'Mooveemart',	'Mona',	'8072403631',	'mona.azhagesan@gmail.com',	'/storage/companies/kamatchi.png',	'Basic',	1,	'2023-02-07',	'2023-02-10 13:16:43',	NULL),
(4,	'Spa',	'Mona',	'8072403631',	'mona.azhagesan@gmail.com',	'/storage/companies/kamatchi.png',	'Basic',	1,	'2023-02-07',	'2023-02-10 13:16:43',	NULL);

DROP TABLE IF EXISTS `companybreaks`;
CREATE TABLE `companybreaks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `minute` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `companybreaks` (`id`, `name`, `minute`, `company_id`, `created_at`, `updated_at`) VALUES
(2,	'Lunch Meal',	20,	1,	'2023-02-28 18:41:26',	NULL);

DROP TABLE IF EXISTS `companysettings`;
CREATE TABLE `companysettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `overtime` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `companysettings` (`id`, `company_id`, `overtime`, `created_at`, `updated_at`) VALUES
(1,	1,	'Manual',	'2023-02-19 13:32:08',	NULL);

DROP TABLE IF EXISTS `contacts`;
CREATE TABLE `contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `contact_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `mobile_number` varchar(255) DEFAULT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `gstin` varchar(255) DEFAULT NULL,
  `billing_address` varchar(255) DEFAULT NULL,
  `shipping_address` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `company_id` (`company_id`),
  CONSTRAINT `contacts_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `contacts` (`id`, `company_id`, `contact_name`, `email`, `mobile_number`, `company_name`, `gstin`, `billing_address`, `shipping_address`, `created_at`, `updated_at`) VALUES
(7,	1,	'Mohan',	'mohan@uniwin.se',	'9876543210',	'Uniwin',	NULL,	NULL,	NULL,	'2023-07-13 05:54:21',	'2023-07-13 05:54:21'),
(8,	1,	'Muthu',	'moovemart@gmail.com',	'9876543210',	'Moovee Mart',	'9874563100',	NULL,	NULL,	'2023-07-13 05:54:55',	'2023-07-13 05:54:55');

DROP TABLE IF EXISTS `customers`;
CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `gstin` varchar(20) DEFAULT NULL,
  `billing_address` varchar(255) DEFAULT NULL,
  `billing_city` varchar(255) DEFAULT NULL,
  `billing_state` varchar(255) DEFAULT NULL,
  `billing_pincode` varchar(20) DEFAULT NULL,
  `billing_country` varchar(20) DEFAULT NULL,
  `shipping_address` varchar(255) DEFAULT NULL,
  `shipping_city` varchar(255) DEFAULT NULL,
  `shipping_state` varchar(255) DEFAULT NULL,
  `shipping_pincode` varchar(20) DEFAULT NULL,
  `shipping_country` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `company_id` (`company_id`),
  CONSTRAINT `customers_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `customers` (`id`, `company_id`, `name`, `mobile`, `email`, `company_name`, `gstin`, `billing_address`, `billing_city`, `billing_state`, `billing_pincode`, `billing_country`, `shipping_address`, `shipping_city`, `shipping_state`, `shipping_pincode`, `shipping_country`, `created_at`, `updated_at`) VALUES
(8,	1,	'Mona Uniwins',	'+46704901197',	'mona@uniwin.se',	NULL,	NULL,	'Kungsgatan 1',	'Stockholm',	NULL,	'111 23',	'Sweden',	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-10-27 18:11:49',	'2023-10-27 18:11:49');

DROP TABLE IF EXISTS `employees`;
CREATE TABLE `employees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employeeid` varchar(255) DEFAULT NULL,
  `company_id` int(11) NOT NULL,
  `branch_id` text DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `doj` date DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `working_days` text DEFAULT NULL,
  `work_start_time` time DEFAULT NULL,
  `work_end_time` time DEFAULT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `ifsc_code` varchar(255) DEFAULT NULL,
  `accountholder_name` varchar(255) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `aadhar_number` varchar(255) DEFAULT NULL,
  `uan_number` varchar(100) DEFAULT NULL,
  `pan_number` varchar(100) DEFAULT NULL,
  `pf_number` varchar(100) DEFAULT NULL,
  `esi_number` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `branch_id` (`branch_id`(1024))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `employees` (`id`, `employeeid`, `company_id`, `branch_id`, `name`, `designation`, `mobile`, `email`, `gender`, `doj`, `address`, `working_days`, `work_start_time`, `work_end_time`, `bank_name`, `account_number`, `ifsc_code`, `accountholder_name`, `dob`, `aadhar_number`, `uan_number`, `pan_number`, `pf_number`, `esi_number`, `created_at`, `updated_at`) VALUES
(1,	NULL,	1,	'1',	'vigneshwaran',	'Accountant',	'09080842066',	'moziztech@gmail.com',	'Male',	NULL,	'Om muruga, 3rd Street,\nThirupparankundram',	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-10 21:17:13'),
(2,	NULL,	1,	'1',	'vigneshwaran',	'sdfsdfsd',	'09080842066',	'moziztech@gmail.com',	'Male',	NULL,	'Om muruga, 3rd Street,\nThirupparankundram',	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 10:49:45'),
(3,	NULL,	1,	'1',	'suman',	'owner',	'99999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 10:50:41'),
(4,	NULL,	1,	'1',	'Dhanush',	'Store Helper',	'8788266220',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 16:18:16'),
(5,	NULL,	1,	'1',	'Muthulakshmi Muthalaikulam',	'Stall',	'9999999999',	NULL,	'Female',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'08:00:00',	'18:00:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 22:07:20'),
(6,	NULL,	1,	'1',	'Priya',	'cashier',	'9999999999',	NULL,	'Female',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 16:40:16'),
(7,	NULL,	1,	'1',	'Ramesh',	'Kal Master',	'9999999999',	NULL,	'Female',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'11:00:00',	'23:00:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 22:09:18'),
(8,	NULL,	1,	'1',	'Kennadi',	'Waiter',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 16:41:53'),
(9,	NULL,	1,	'1',	'Bala',	'Waiter',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Sat\"]',	'08:00:00',	'23:00:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 22:08:31'),
(10,	NULL,	1,	'1',	'Ramani',	'Waiter',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 16:42:55'),
(11,	NULL,	1,	'1',	'Anand',	'Chainese Master',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 16:43:39'),
(12,	NULL,	1,	'1',	'Kuruvammal',	'Dishwash',	'9999999999',	NULL,	'Female',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 16:44:13'),
(13,	NULL,	1,	'1',	'Alagammal Puliyankulam',	'Dishwash',	'9999999999',	NULL,	'Female',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 16:45:07'),
(14,	NULL,	1,	'1',	'Ramuthai',	'Dishwash',	'9999999999',	NULL,	'Female',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:14:58'),
(15,	NULL,	1,	'1',	'Sethupathi',	'Part time waiter',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:15:43'),
(16,	NULL,	1,	'1',	'Chanakkiya',	'Part time waiter',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:16:18'),
(17,	NULL,	1,	'1',	'Azarudeen',	'Part time waiter',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:16:53'),
(18,	NULL,	1,	'1',	'Baskar',	'Part time waiter',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:17:26'),
(19,	NULL,	1,	'1',	'Santhosh',	'Part time waiter',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:17:58'),
(20,	NULL,	1,	'1',	'Charuhazan',	'Part time waiter',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:18:36'),
(21,	NULL,	1,	'1',	'Alagarasan',	'Part time waiter',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:19:20'),
(22,	NULL,	1,	'1',	'Bharathi',	'Stall',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:19:55'),
(23,	NULL,	1,	'1',	'Muthulakshmi Vadapalanji',	'Dishwash',	'9999999999',	NULL,	'Female',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:20:44'),
(24,	NULL,	1,	'1',	'Siva',	'Manager',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:26:06'),
(25,	NULL,	1,	'1',	'Vasikannan',	'cashier',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:26:59'),
(26,	NULL,	1,	'1',	'Amuthan',	'Master',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:27:36'),
(27,	NULL,	1,	'1',	'Kannan',	'Master',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:28:06'),
(28,	NULL,	1,	'1',	'Nepolian',	'Waiter',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:31:00'),
(29,	NULL,	1,	'1',	'Senthamil',	'Asst Master',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:31:45'),
(30,	NULL,	1,	'1',	'Parameswari',	'Dishwash',	'9999999999',	NULL,	'Female',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:32:20'),
(31,	NULL,	1,	'1',	'Deepak',	'Kal Master',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:34:18'),
(32,	NULL,	1,	'1',	'Arulmurugan',	'Stall',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:35:48'),
(33,	NULL,	1,	'1',	'Ramu',	'Asst Master',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:36:37'),
(34,	NULL,	1,	'1',	'Sasikumar',	'Waiter',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:37:11'),
(35,	NULL,	1,	'1',	'Muthulakshmi Karumaththur',	'Dishwash',	'9999999999',	NULL,	'Female',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:38:14'),
(36,	NULL,	1,	'1',	'Araman',	'Driver Cleaner',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:39:19'),
(37,	NULL,	1,	'1',	'Vetri',	'Stall',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:39:58'),
(38,	NULL,	1,	'1',	'Nagaraj',	'Waiter',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:40:21'),
(39,	NULL,	1,	'1',	'Pradeep',	'Waiter',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:40:51'),
(40,	NULL,	1,	'1',	'Vembaiyan',	'Aravai',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:41:24'),
(41,	NULL,	1,	'1',	'Alagammal Pullaneri',	'Dishwash',	'9999999999',	NULL,	'Female',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:41:59'),
(42,	NULL,	1,	'1',	'Ramya',	'Dishwash',	'9999999999',	NULL,	'Female',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:42:28'),
(43,	NULL,	1,	'1',	'Jeeva',	'Dishwash',	'9999999999',	NULL,	'Female',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:42:51'),
(44,	NULL,	1,	'1',	'Usilai Siva',	'Bakkery Master',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:43:36'),
(45,	NULL,	1,	'1',	'Santhanam',	'Cake Master',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:44:07'),
(46,	NULL,	1,	'1',	'Venkatesh',	'Asst Bakkery master',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:45:39'),
(47,	NULL,	1,	'1',	'Thangavel',	'Dishwash',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:46:27'),
(48,	NULL,	1,	'1',	'Srimanth',	'Sweet Master',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:47:19'),
(49,	NULL,	1,	'1',	'Srimanth',	'Boli',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'16:00:00',	'20:00:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 21:39:45'),
(50,	NULL,	1,	'1',	'Babu',	'Asst Bakkery master',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:48:31'),
(51,	NULL,	1,	'1',	'Amith',	'Asst Bakkery master',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:48:58'),
(52,	NULL,	1,	'1',	'Amith',	'Boli',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:49:23'),
(53,	NULL,	1,	'1',	'Mani',	'Kaaram Master',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:49:49'),
(54,	NULL,	1,	'1',	'Anand',	'Cake Master',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:55:06'),
(55,	NULL,	1,	'1',	'Ganesan',	'Master',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:57:24'),
(56,	NULL,	1,	'1',	'Ganesan',	'Driver',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:57:52'),
(57,	NULL,	1,	'1',	'Alagar',	'Helper',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:58:48'),
(58,	NULL,	1,	'1',	'Rajavelu',	'cashier',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 18:59:38'),
(59,	NULL,	1,	'1',	'Ajithkumar',	'Vadai Master',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 19:00:43'),
(60,	NULL,	1,	'1',	'Kumar',	'Master',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 19:05:56'),
(61,	NULL,	1,	'1',	'Boomi',	'cashier',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 19:06:36'),
(62,	NULL,	1,	'1',	'Rishwan',	'Helper',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 19:06:59'),
(63,	NULL,	1,	'1',	'Sivaji',	'cashier',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 19:07:33'),
(64,	NULL,	1,	'1',	'Selvam',	'Sales man',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 19:07:55'),
(65,	NULL,	1,	'1',	'Bakkiyalakshmi',	'Sales woman',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 19:09:08'),
(66,	NULL,	1,	'1',	'Prakash',	'Sales man',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 19:09:43'),
(67,	NULL,	1,	'1',	'satheeswaran',	'Sales man',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 19:10:06'),
(68,	NULL,	1,	'1',	'selvam',	'Master',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 19:13:03'),
(69,	NULL,	1,	'1',	'Dhavamani',	'Table Cleaning',	'9999999999',	NULL,	'Female',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 19:15:07'),
(70,	NULL,	1,	'1',	'Selvaraj',	'Waiter',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 19:15:32'),
(71,	NULL,	1,	'1',	'santhanam',	'watchman',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 19:16:04'),
(72,	NULL,	1,	'1',	'Sudharsan',	'cashier',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 19:16:33'),
(73,	NULL,	1,	'1',	'Vishwa',	'Waiter',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 19:39:44'),
(74,	NULL,	1,	'1',	'Murugan  sumathi',	'Scavanger',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'06:00:00',	'18:00:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 21:45:58'),
(75,	NULL,	1,	'1',	'Muthupandi',	'Waiter',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 19:56:07'),
(76,	NULL,	1,	'1',	'Poosaram',	'Dishwash',	'9999999999',	NULL,	'Female',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 19:56:56'),
(77,	NULL,	1,	'1',	'Sarojadevi',	'Dishwash',	'9999999999',	NULL,	'Female',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 19:57:40'),
(78,	NULL,	1,	'1',	'Nivisthiya',	'cashier',	'9999999999',	NULL,	'Female',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 19:58:34'),
(79,	NULL,	1,	'1',	'Mani',	'Chainese Master',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 19:59:02'),
(80,	NULL,	1,	'1',	'Ramki',	'Stall',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 20:02:57'),
(81,	NULL,	1,	'1',	'karuppusamy',	'Waiter',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 20:06:28'),
(82,	NULL,	1,	'1',	'Rajesh',	'cashier',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 20:10:30'),
(83,	NULL,	1,	'1',	'Selvam',	'Waiter',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-11 20:11:51'),
(84,	NULL,	1,	'1',	'Alexpandi',	'cashier',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'19:00:00',	'23:00:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 22:02:08'),
(85,	NULL,	1,	'1',	'Balamurugan',	'cashier',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'22:30:00',	'08:30:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 21:19:04'),
(86,	NULL,	1,	'1',	'Selvakannan',	'Sales man',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[\"Sun\",\"Sat\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\"]',	'22:30:00',	'08:30:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 21:20:58'),
(87,	NULL,	1,	'1',	'Muthukalai',	'Sales man',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'22:30:00',	'08:30:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 21:22:31'),
(88,	NULL,	1,	'1',	'Murugesan',	'cashier',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'22:30:00',	'08:30:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 21:23:45'),
(89,	NULL,	1,	'1',	'Moovendran',	'Tea Master',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'22:30:00',	'08:30:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 21:24:49'),
(90,	NULL,	1,	'1',	'Thangam',	'Tea Master',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'22:30:00',	'08:30:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 21:26:01'),
(91,	NULL,	1,	'1',	'Anupriya',	'Vadai Master',	'9999999999',	NULL,	'Female',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'23:30:00',	'10:30:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 21:28:14'),
(92,	NULL,	1,	'1',	'Dhanalakshmi',	'Dishwash',	'9999999999',	NULL,	'Female',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'23:30:00',	'11:30:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 21:30:20'),
(93,	NULL,	1,	'1',	'Chappani',	'Helper',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 21:31:55'),
(94,	NULL,	1,	'1',	'Subramani P',	'Helper',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'08:30:00',	'17:30:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 21:33:52'),
(95,	NULL,	1,	'1',	'Virumandi',	'Sales man',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'08:30:00',	'17:30:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 21:34:48'),
(96,	NULL,	1,	'1',	'Pradhab',	'Sales man',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'08:30:00',	'17:30:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 21:35:47'),
(97,	NULL,	1,	'1',	'Paraman',	'tea',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'08:30:00',	'17:30:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 21:36:35'),
(98,	NULL,	1,	'1',	'Vairam',	'Tea Master',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'08:30:00',	'17:30:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 21:37:46'),
(99,	NULL,	1,	'1',	'Kani',	'cashier',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'08:30:00',	'17:30:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 21:38:29'),
(100,	NULL,	1,	'1',	'Kasi',	'cashier',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'22:30:00',	'08:30:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 21:41:03'),
(101,	NULL,	1,	'1',	'Sureshkumar',	'cashier',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'22:30:00',	'08:30:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 21:41:47'),
(102,	NULL,	1,	'1',	'Rajkumar',	'cashier',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'22:30:00',	'08:30:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 21:42:30'),
(103,	NULL,	1,	'1',	'Jagadesh',	'Vadai Master',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Thu\",\"Fri\",\"Sat\"]',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 21:43:14'),
(104,	NULL,	1,	'1',	'Periyapandi',	'security',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'00:30:00',	'12:30:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 21:46:48'),
(105,	NULL,	1,	'1',	'Balamurugan',	'Store incharge',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'01:30:00',	'10:30:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 21:48:20'),
(106,	NULL,	1,	'1',	'Saravanan',	'Waiter',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'08:30:00',	'17:30:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 21:49:06'),
(107,	NULL,	1,	'1',	'Duraipandi',	'Tea Master',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'08:30:00',	'17:30:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 21:49:58'),
(108,	NULL,	1,	'1',	'Nagendran',	'cashier',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'08:30:00',	'17:30:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 21:50:55'),
(109,	NULL,	1,	'1',	'Suryaprakash',	'cashier',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'22:30:00',	'09:30:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 21:51:59'),
(110,	NULL,	1,	'1',	'Vadivel G',	'cashier',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'01:30:00',	'13:30:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 21:52:49'),
(111,	NULL,	1,	'1',	'Jaya',	'Billing',	'9999999999',	NULL,	'Female',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'03:00:00',	'12:30:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 21:55:13'),
(112,	NULL,	1,	'1',	'Pandiyammal',	'Sales woman',	'9999999999',	NULL,	'Female',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'03:30:00',	'06:37:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 21:56:29'),
(113,	NULL,	1,	'1',	'RajaRam',	'Helper',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'03:30:00',	'06:36:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 21:58:02'),
(114,	NULL,	1,	'1',	'Rameshwari',	'Dishwash',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'03:00:00',	'12:30:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 21:59:38'),
(115,	NULL,	1,	'1',	'Priya B',	'Accountant',	'9999999999',	NULL,	'Female',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'03:30:00',	'13:30:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 22:00:50'),
(116,	NULL,	1,	'1',	'Priya B',	'Accountant',	'9999999999',	NULL,	'Female',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'03:30:00',	'13:30:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 22:00:52'),
(117,	NULL,	1,	'1',	'Balamurugan',	'Bakkery',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'00:30:00',	'17:30:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 22:04:16'),
(118,	NULL,	1,	'1',	'Muthusamy P',	'cashier',	'9999999999',	NULL,	'Male',	NULL,	NULL,	'[\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"]',	'00:30:00',	'17:30:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-15 15:35:37',	'2023-02-13 22:05:10'),
(119,	NULL,	1,	NULL,	'vigneshwaran multiple branch test',	'Deer',	'09080842066',	'moziztech@gmail.com',	'Male',	'2023-02-22',	'Om muruga, 3rd Street,\nThirupparankundram',	'[\"Sun\",\"Sat\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\"]',	'20:32:00',	'22:30:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-02-19 06:25:01',	'2023-02-19 06:25:01');

DROP TABLE IF EXISTS `expenses`;
CREATE TABLE `expenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `expenseid` varchar(255) DEFAULT NULL,
  `company_id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `expensetype_id` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `method` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `expenses_ibfk_1` (`branch_id`),
  CONSTRAINT `expenses_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `expenses_type`;
CREATE TABLE `expenses_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `expensetype` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  `company_id` int(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `expenses_type` (`id`, `expensetype`, `created_at`, `updated_at`, `company_id`) VALUES
(6,	'dsfdsff',	'2023-03-02 15:33:08',	'2023-03-02 15:33:08',	NULL);

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `invoices`;
CREATE TABLE `invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `invoice_no` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `company_id` (`company_id`),
  CONSTRAINT `invoices_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `items`;
CREATE TABLE `items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `type` tinyint(4) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `image` varchar(255) NOT NULL,
  `unit` varchar(255) NOT NULL,
  `price` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `company_id` (`company_id`),
  CONSTRAINT `items_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `latepenalty_settings`;
CREATE TABLE `latepenalty_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `allowed_days` int(11) NOT NULL,
  `deduction_type` varchar(255) NOT NULL,
  `deduction_rate` double NOT NULL,
  `grace_period` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_id` (`employee_id`),
  CONSTRAINT `latepenalty_settings_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1,	'2014_10_12_000000_create_users_table',	1),
(2,	'2014_10_12_100000_create_password_resets_table',	1),
(3,	'2019_08_19_000000_create_failed_jobs_table',	1),
(4,	'2019_12_14_000001_create_personal_access_tokens_table',	1),
(5,	'2023_01_19_155210_create_blogs_table',	1);

DROP TABLE IF EXISTS `overtimesettings`;
CREATE TABLE `overtimesettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `weekoff_pay` double NOT NULL,
  `publicholiday_pay` double NOT NULL,
  `extra_hours_pay` double NOT NULL,
  `grace_period` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_id` (`employee_id`),
  CONSTRAINT `overtimesettings_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `parties`;
CREATE TABLE `parties` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `partyname` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `who_r_they` varchar(255) NOT NULL,
  `gstin` varchar(255) NOT NULL,
  `flat_no` varchar(255) NOT NULL,
  `area_loc` varchar(255) NOT NULL,
  `pincode` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `same_ship` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('mona.azhagesan@gmail.com',	'$2y$10$IzDG0vMQ5Y6SS9xocEr1Au2CsvacHF75wbMOvkVGMG5CjIOUWJkAS',	'2023-08-23 07:04:29');

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `category` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `sku` varchar(255) DEFAULT NULL,
  `hsn` varchar(255) DEFAULT NULL,
  `unit` varchar(255) DEFAULT NULL,
  `default_quantity` varchar(255) DEFAULT NULL,
  `purchase_price` double DEFAULT NULL,
  `sales_price` double DEFAULT NULL,
  `tax` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `products` (`id`, `company_id`, `name`, `category`, `image`, `sku`, `hsn`, `unit`, `default_quantity`, `purchase_price`, `sales_price`, `tax`, `description`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	1,	'Mirroring Deer Garden A6 Notebook',	'2',	'storage/1/products/bvVQw9xuSpEs70OsYbBUtExlTz3bTB8w9ZRat41c.jpg',	'100001',	'100001100001',	'3',	NULL,	100,	299,	1,	'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.',	'2023-07-27 05:06:18',	'2023-07-27 05:06:18',	'2023-07-27 05:06:18'),
(2,	1,	'Purssian Perching Floral Paradise A5 Notebook',	'2',	'storage/1/products/I3QOck2Sg0aT0Vqxpk4l5UsS6I4jjbc1jlMHBmZD.jpg',	'100001',	'100001100001',	'3',	NULL,	100,	299,	1,	'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.',	'2023-07-27 05:06:22',	'2023-07-27 05:06:22',	'2023-07-27 05:06:22'),
(3,	1,	'Quivering Sublime A5 Notebook',	'2',	'storage/1/products/MJodHthelZ4ICWiB6C63QOeTQAksDVtxSkKKhfNe.jpg',	'100001',	'100001100001',	'3',	NULL,	100,	299,	1,	'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.',	'2023-07-27 05:06:25',	'2023-07-27 05:06:25',	'2023-07-27 05:06:25'),
(4,	1,	'Striking Entwine A6 Notebook',	'2',	'storage/1/products/IKD3TWt1Znt2KNaBh9yQA22ChiMIT7fRViVdb6Ea.jpg',	'100001',	'100001100001',	'3',	NULL,	100,	299,	1,	'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.',	'2023-07-27 05:06:28',	'2023-07-27 05:06:28',	'2023-07-27 05:06:28'),
(5,	1,	'dfgdgdfgdgdf',	'dfdfdfdfg',	'storage/1/products/Z6AI6AxRnQTIAHYf2jZkSDLCkIkzAVOXZ25dqxsO.jpg',	'100001',	'rtret45435',	'dfddfgd',	NULL,	4543,	100,	1,	'dfgdfgdfg',	'2023-07-27 05:07:50',	'2023-07-27 05:07:50',	NULL),
(6,	1,	'dfgdgdfgdgdf',	'dfdfdfdfg',	'storage/1/products/87Bjtk8npxSIKi6wxu14DdprSHocETBcf6OFD4JY.jpg',	'100001',	'rtret45435',	'dfddfgd',	NULL,	4543,	100,	1,	'dfgdfgdfg',	'2023-07-27 05:08:27',	'2023-07-27 05:08:27',	NULL),
(7,	1,	'sdfsdfsdfsd',	'asdadasdasd',	'storage/1/products/EG03OTz9oTr5EgCuVQjsd11ct7aqn9sUbV6nyWtp.png',	'3213213213',	'sdfsdfsdfs',	'Bags',	NULL,	324234,	3324,	1,	'fdgdfgfdgdf',	'2023-07-27 05:18:13',	'2023-07-27 05:18:13',	NULL),
(8,	1,	'dsfsdfsdf',	'sdfsdfsd',	'storage/1/products/daHEfHO1Gpz5h3xpFIsgYzu90nuMoi9F34pnpXby.png',	'dsfsdf',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-07-27 05:19:03',	'2023-07-27 05:19:03',	NULL),
(9,	1,	'reterttreterter',	'fdfdgdfgdg',	'storage/1/products/ckE3unYOO11Meoh97izfSdfSYVL12Guhcl2fv9xG.png',	'fddfgdgd',	'dgdfdg',	'dfgdgdf',	NULL,	4335435,	43543,	1,	'fdgdfgfgd fdgdfgfgd fdgdfgfgd fdgdfgfgd fdgdfgfgd',	'2023-07-27 05:24:44',	'2023-07-27 05:24:44',	'2023-07-27 05:24:44'),
(10,	1,	'gfhfghfgh',	NULL,	'storage/1/products/u24e3wfSTGeZAQvCUkvhbk217Iu4QdChc7Vd10Rj.png',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-07-27 05:24:40',	'2023-07-27 05:24:40',	'2023-07-27 05:24:40'),
(11,	1,	'gfhfhfgh',	NULL,	'storage/1/products/iFTiGvt4LqCOkwvhs1yVtSZOpzN9BfU3zIWCEtz6.jpg',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-07-27 05:24:38',	'2023-07-27 05:24:38',	'2023-07-27 05:24:38'),
(12,	1,	'ghfgfghfh',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-07-27 05:25:15',	'2023-07-27 05:25:15',	NULL);

DROP TABLE IF EXISTS `salarydetails`;
CREATE TABLE `salarydetails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `salary_type` varchar(255) NOT NULL,
  `salary_amount` double NOT NULL,
  `allowances` text DEFAULT NULL,
  `pf_detail` varchar(255) DEFAULT NULL,
  `pf_amount` double DEFAULT NULL,
  `esi_detail` varchar(255) DEFAULT NULL,
  `esi_amount` double DEFAULT NULL,
  `ctc` double DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_id` (`employee_id`),
  CONSTRAINT `salarydetails_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `sales`;
CREATE TABLE `sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL,
  `number` varchar(255) NOT NULL,
  `sales_date` date NOT NULL,
  `subtotal` double NOT NULL,
  `discount_value` varchar(255) NOT NULL,
  `discount_amount` double NOT NULL,
  `shipping_cost` double NOT NULL,
  `terms_condition` text NOT NULL,
  `notes` text NOT NULL,
  `order_status` enum('New','Completed','Hold') NOT NULL DEFAULT 'New',
  `payment_method` varchar(255) NOT NULL,
  `shipping_method` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `company_id` (`company_id`),
  KEY `contact_id` (`contact_id`),
  CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  CONSTRAINT `sales_ibfk_2` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `services`;
CREATE TABLE `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `sac` varchar(255) DEFAULT NULL,
  `unit` varchar(255) DEFAULT NULL,
  `default_quantity` float DEFAULT NULL,
  `rate` double DEFAULT NULL,
  `tax` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `services` (`id`, `company_id`, `name`, `sac`, `unit`, `default_quantity`, `rate`, `tax`, `description`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	1,	'Web development',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-07-27 03:08:04',	'2023-07-27 03:08:04',	'2023-07-27 03:08:04'),
(2,	1,	'App development',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-07-27 03:08:13',	'2023-07-27 03:08:13',	'2023-07-27 03:08:13'),
(3,	1,	'Wordpress development',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-07-27 03:08:15',	'2023-07-27 03:08:15',	'2023-07-27 03:08:15'),
(4,	1,	'HTML Page  development',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-07-27 03:08:00',	'2023-07-27 03:08:00',	'2023-07-27 03:08:00'),
(5,	1,	'Logo Design',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-07-27 03:09:32',	'2023-07-27 03:09:32',	'2023-07-27 03:09:32'),
(6,	1,	'test',	'',	'hrly',	NULL,	NULL,	1,	'test',	'2023-07-27 03:09:49',	'2023-07-27 03:09:49',	'2023-07-27 03:09:49'),
(7,	1,	'dfdgdf',	'002',	'dgfdg',	NULL,	200,	1,	'dfgdfgdf',	'2023-07-27 03:11:06',	'2023-07-27 03:11:06',	'2023-07-27 03:11:06'),
(8,	1,	'dssdfsdf',	'003',	'sdfsfsdf',	20,	3324234,	1,	'sfsdfsdfsf',	'2023-07-27 03:09:28',	'2023-07-27 03:09:28',	'2023-07-27 03:09:28'),
(9,	1,	'dfgdfgd',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-07-27 03:14:06',	'2023-07-27 03:14:06',	'2023-07-27 03:14:06'),
(10,	1,	'dfdgfdgdfg',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-07-27 03:14:30',	'2023-07-27 03:14:30',	'2023-07-27 03:14:30'),
(11,	1,	'fgfghff',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-07-27 03:14:47',	'2023-07-27 03:14:47',	'2023-07-27 03:14:47'),
(12,	1,	'sdfsdfsdfds',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-07-27 03:15:20',	'2023-07-27 03:15:20',	'2023-07-27 03:15:20'),
(13,	1,	'dsdfsfsdfs',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-07-27 03:26:08',	'2023-07-27 03:26:08',	'2023-07-27 03:26:08'),
(14,	1,	'asadasadasdas',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-07-27 03:26:05',	'2023-07-27 03:26:05',	'2023-07-27 03:26:05'),
(15,	1,	'asadasadasdas',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-07-27 03:25:55',	'2023-07-27 03:25:55',	'2023-07-27 03:25:55'),
(16,	1,	'asadasadasdassdsdf',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-07-27 03:25:42',	'2023-07-27 03:25:42',	'2023-07-27 03:25:42'),
(17,	1,	'asadasadasdassdsdf',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-07-27 03:25:35',	'2023-07-27 03:25:35',	'2023-07-27 03:25:35'),
(18,	1,	'asadasadasdassdsdf',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-07-27 03:25:37',	'2023-07-27 03:25:37',	'2023-07-27 03:25:37'),
(19,	1,	'asadasadasdassdsdf',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-07-27 03:24:19',	'2023-07-27 03:24:19',	'2023-07-27 03:24:19'),
(20,	1,	'dsfsdfsdf',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-07-27 03:25:31',	'2023-07-27 03:25:31',	'2023-07-27 03:25:31'),
(21,	1,	'dsfsdfsdfssdfsdfsf',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-07-27 03:25:18',	'2023-07-27 03:25:18',	'2023-07-27 03:25:18'),
(22,	1,	'a',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-07-27 03:25:15',	'2023-07-27 03:25:15',	'2023-07-27 03:25:15'),
(23,	1,	'dsdfsfsdfsdf',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-07-27 04:55:09',	'2023-07-27 04:55:09',	'2023-07-27 04:55:09'),
(24,	1,	'sadasda',	'sadasd',	'asdas',	23,	312321,	1,	'dasdsdasdsd',	'2023-07-27 04:55:05',	'2023-07-27 04:55:05',	NULL),
(25,	1,	'Main Category',	'002',	'Box',	25,	50,	2,	'test1',	'2023-08-09 15:58:43',	'2023-08-09 15:58:43',	NULL);

DROP TABLE IF EXISTS `taxes`;
CREATE TABLE `taxes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `tax` varchar(255) NOT NULL,
  `value` double NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `taxes` (`id`, `company_id`, `tax`, `value`, `created_at`, `updated_at`) VALUES
(1,	0,	'GST 12%',	12,	'2023-06-29 03:34:18',	NULL),
(2,	0,	'GST 14%',	14,	'2023-06-29 03:34:27',	NULL);

DROP TABLE IF EXISTS `units`;
CREATE TABLE `units` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(255) NOT NULL,
  `company_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `units` (`id`, `unit`, `company_id`, `created_at`, `updated_at`) VALUES
(1,	'Bags',	0,	'0000-00-00 00:00:00',	NULL),
(2,	'Bottles',	0,	'0000-00-00 00:00:00',	NULL),
(3,	'Box',	0,	'0000-00-00 00:00:00',	NULL),
(4,	'hr',	0,	'2023-07-20 17:43:04',	NULL),
(5,	'Month',	0,	'2023-07-20 17:43:11',	NULL);

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `company_id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `company_id` (`company_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `users` (`id`, `name`, `company_id`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1,	'Suman Raj',	1,	'sumanraj16792@gmail.com',	NULL,	'$2y$10$NPRs1b89Cwul4k.gl/GytOEBAFgt9FPy6vKB4YxzyGWytwESk.bxC',	NULL,	'2023-01-19 16:14:20',	'2023-01-19 16:14:20'),
(2,	'Mohana',	1,	'mona.azhagesan@gmail.com',	NULL,	'$2y$10$NPRs1b89Cwul4k.gl/GytOEBAFgt9FPy6vKB4YxzyGWytwESk.bxC',	NULL,	'2023-01-19 16:14:20',	'2023-01-19 16:14:20');

-- 2023-10-27 18:22:39
